$(document).ready(function () {

    //business map
      var longitude = $('#map_longitude').val();
      var latitude = $('#map_latitude').val();
      var location = $('#map_location').val();
      var location_name = $('#map_location_name').val();
      var i;
      var zoomdisplay = 14;
      var bounds = new google.maps.LatLngBounds();
      var image = {
        url: '/assets/map_icon.png',
        size: new google.maps.Size(48, 58),
        origin: new google.maps.Point(0,0)
      };
    if (latitude != ""){
      var map = new google.maps.Map(document.getElementById('business-map'), {
        zoom: zoomdisplay,
        maxZoom: zoomdisplay,
        minZoom: zoomdisplay,
        mapTypeControl: false,
        draggable: false,
        scaleControl: false,
        scrollwheel: false,
        navigationControl: false,
        streetViewControl: false,
        panControl: false,
        zoomControl: false,
        center: new google.maps.LatLng(latitude, longitude),
        mapTypeId: google.maps.MapTypeId.ROADMAP
      });
      markers = new google.maps.Marker({
          position: new google.maps.LatLng(latitude, longitude),
          map: map,
          icon: image
        });
    }else{
      var i,geocoder,map,lat,lng,marker,markers;
      var address = location;
      geocoder = new google.maps.Geocoder();
      geocoder.geocode( { 'address': address, 'region': 'ph' }, function(results, status) {
          if (status == google.maps.GeocoderStatus.OK) {
            map = new google.maps.Map(document.getElementById('business-map'), {
              zoom: zoomdisplay,
              maxZoom: zoomdisplay,
              minZoom: zoomdisplay,
              draggable: false,
              scaleControl: false,
              scrollwheel: false,
              navigationControl: false,
              streetViewControl: false,
              mapTypeControl: false,
              panControl: false,
              zoomControl: false,
              center: new google.maps.LatLng(results[0].geometry.location.lat(),results[0].geometry.location.lng()),
              mapTypeId: google.maps.MapTypeId.ROADMAP
            });
             map.setCenter(results[0].geometry.location);
            marker = new google.maps.Marker({
              map: map,
              position: results[0].geometry.location,
              icon: image
            });
          }else{
              var address = location_name;
              geocoder.geocode( { 'address': address, 'region': 'ph' }, function(results, status) {
              if (status == google.maps.GeocoderStatus.OK) {
                map = new google.maps.Map(document.getElementById('business-map'), {
                  zoom: 16,
                  mapTypeControl: true,
                  center: new google.maps.LatLng(results[0].geometry.location.lat(),results[0].geometry.location.lng()),
                  mapTypeId: google.maps.MapTypeId.ROADMAP
                });

                 map.setCenter(results[0].geometry.location);
                marker = new google.maps.Marker({
                  map: map,
                  position: results[0].geometry.location,
                  icon: image
                });
                google.maps.event.addListener(marker, 'click', (function(marker, i) {
                    return function() {
                      ib.open(map, this);
                    }
                  })(marker, i));
                var ib = new InfoBox(myOptions);
                ib.open(map, marker);
              }
            });
          }
        });
     }
});