$(document).ready(function () {

    //$('#review-default-sort-arrow').attr('src','/assets/arrow_up.png').css('display','inline');

    var $HeightContact = $('.info-contact');
    var maxHeight = 0;
    $HeightContact.each(function() { maxHeight = Math.max(maxHeight, $(this).outerHeight()); });
    $HeightContact.css({ height: maxHeight + 'px' });

    var $HeightFeatures = $('.info-features');
    $HeightFeatures.each(function() { maxHeight = Math.max(maxHeight, $(this).outerHeight()); });
    $HeightFeatures.css({ height: maxHeight + 'px' });

    var $HeightServices = $('.info-services');
    $HeightServices.each(function() { maxHeight = Math.max(maxHeight, $(this).outerHeight()); });
    $HeightServices.css({ height: maxHeight + 'px' });

    var $HeightCategories = $('.info-categories');
    $HeightCategories.each(function() { maxHeight = Math.max(maxHeight, $(this).outerHeight()); });
    $HeightCategories.css({ height: maxHeight + 'px' });

    var $HeightTags = $('.info-tags');
    $HeightTags.each(function() { maxHeight = Math.max(maxHeight, $(this).outerHeight()); });
    $HeightTags.css({ height: maxHeight + 'px' });

    // Hide all comments & Hide close icons
    $('.review-comment-wrap, .comment-close').hide();
    $('.article-comment-wrap, .article-comment-close').hide();

    // Slide down comments
    $(".comment-icon").live("click", function () {
        var t = $(this).closest('.review-comments');
        t.find(".review-comment-wrap").slideDown();
        t.find('.comment-close').show();
    });
    // Slide down comments
    $(".article-comment-icon").live("click", function () {
        var t = $(this).closest('.article-comments');
        t.find(".article-comment-wrap").slideDown();
        t.find('.article-comment-close').show();
    });
    // Slide up comments
    $(".comment-close").live("click", function () {
        var t = $(this).closest('.review-comments');
        t.find(".review-comment-wrap").slideUp();
        t.find('.comment-close').hide();
    });

    $(".article-comment-close").live("click", function () {
        var t = $(this).closest('.article-comments');
        t.find(".article-comment-wrap").slideUp();
        t.find('.article-comment-close').hide();
    });

    $('#a_write_review').click(function(e) {
        e.preventDefault();

        var full_url = this.href;
        var rrok_tab_active = $('#t-rrok').attr('class');

        if(rrok_tab_active == ""){
            $('a[href = "#tab-rantsraves"]').trigger('click');
        }

        //split the url by # and get the anchor target name - home in mysitecom/index.htm#home
        var hash = full_url.split("#");

        var target = "#"+hash[1];

        //get the top offset of the target anchor
        var target_offset = $(target).offset();

        //goto that anchor by setting the body scroll top to anchor top
        $('html,body').animate({scrollTop: target_offset.top},'slow');
    });

    $('#share_bus_article').click(function(e) {
        e.preventDefault();
        $('.business_article_form').show(1000);
        $('#share_bus_article').hide();
    });

    $('#share_bus_photo').click(function(e) {
        e.preventDefault();
        $('.business_photo_form').show(1000);
        $('#share_bus_photo').hide();
    });

    $('#share_bus_file').click(function() {
        $('.business_file_form').slideDown("slow");
        $('.arrow').html('').show();
    });

    $('#share_bus_video').click(function(e) {
        e.preventDefault();
        $('.business_video_form').show(1000);
        $('#share_bus_video').hide();
    });

    $('#cancel_button').click(function(e) {
        e.preventDefault();
        $('.business_photo_form, #image_preview_photo').hide();
        $('#img_prev_photo').attr('src', '');
        $('#share_bus_photo').show();
        $('.business_photo_result').html('').hide();
        $('#business_photo_title,#business_photo_description,#business_photo_uploaded_data,#association_photo_uploaded_data').val('');
        $('.field_error').html('');
    });

    $('#cancel_button_file').click(function() {
        $('.business_file_form').slideUp("slow");
        $('#share_bus_file').show();
        $('.business_file_result').html('').hide();
        $('.arrow').html('').hide();
        $('.field_error').html('');
        $('html,body').animate({'scrollTop' : 0},1000);
    });

    //Business photo submit
    $('#post_business_photo').live("click", function() {
        $(".img_loader_photo").show();
        $("#post_business_photo, #cancel_button, .cancel_image_business_photo").hide();
        setTimeout(function () {
            $("#new_business_photo").submit();
        }, 2000);
    });

    $('#new_business_photo').ajaxForm();

    //Business video submit
    $('#post_business_video').live("click", function(e) {
        var textEmbedVideo = $("#textEmbedVideo").val().trim();
        var business_id    = $("#bv_bid").val();

        if(textEmbedVideo != ""){
            var yturl_slpit = textEmbedVideo.split("/");

            if(yturl_slpit.length > 3){
                if(yturl_slpit[2] == "www.youtube.com"){
                    $(".img_loader_video").show();
                    $("#post_business_video, #cancel_button_video").hide();

                    var yt_id = yturl_slpit[3].split("=");
                    var yt_id2 = yt_id[1].split("&")

                    if(yt_id2.length > 1){
                        yt_id = yt_id2[0]
                    }else{
                        yt_id = yt_id[1]
                    }

                    $.ajax({
                        url: "http://gdata.youtube.com/feeds/api/videos/"+yt_id+"?v=2&alt=json",
                        dataType: "jsonp",
                        success: function (data) {
                            var yt_title = data.entry.title.$t;
                            var yt_published = data.entry.published.$t.substring(0,10);
                            var yt_description = data.entry.media$group.media$description.$t;
                            var yt_author = data.entry.author[0].name.$t;

                            $.post("/business_video/create_video",{
                                business_id:business_id,
                                yt_title:yt_title,
                                yt_description:yt_description,
                                yt_id:yt_id,
                                yt_author:yt_author,
                                yt_published:yt_published
                            });
                        }
                    });
                }else{
                    alert("Make sure its a Youtube url.");
                }

            }else{
                alert("Make sure its a Youtube url.");
            }

        }else{
            alert("Youtube url is empty.");
        }
    });

    $('#cancel_button_video').click(function(e) {
        e.preventDefault();
        $('.business_video_form, .business_video_result').hide();
        $('#share_bus_video').show();
        $('#textEmbedVideo').val('');
    });

    //Business article
    $('#post_business_article').live("click", function() {
        $(".img_loader_article").show();
        $("#post_business_article, #cancel_button_article").hide();
        setTimeout(function () {
            $("#new_business_article").submit();
        }, 2000);
    });

    $('.thumb-article').live("click", function() {
        var img_src = $(this).attr('src');
        $('.thumb-article').css('border-style', 'none');
        if(img_src != "/assets/article-default.jpg"){
            $("#business_article_image_url").val(img_src);
        }else{
            $("#business_article_image_url").val("");
        }
        $(this).css('border-style', 'solid').css('border-width', '5px').css('border-color', '#F8C52E');
    });

    //Business article url
    $('#get_business_article').live("click", function() {
        var article_url = $("#business_article_url").val();

        if(/^(https?|ftp):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(\#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i.test(article_url) && $.trim(article_url) != "") {
            $("#get_business_article, #cancel_button_article").hide();
            $(".img_loader_article").show();
            $.ajax({
                type:"GET",
                url:"/business_article/get_article_data",
                data:{
                    article_url:article_url
                }
            });
        }else{
            alert("Invalid URL.");
        }
    });

    $('#new_business_article').ajaxForm();

    $('#cancel_button_article').click(function(e) {
        e.preventDefault();
        $('#share_bus_article,#get_business_article').show();
        $(".business_article_form,.business_article_result,.div_article_title,.div_article_blurb,.div_article_keyword,#post_business_article").hide();

        $(".imgpath").html("");
        $('#new_business_article')[0].reset();
    });
    //end

    //Comment Review submit
    $('[id=post_comment_review]').live("click", function() {
        //alert($(this).parent("#new_review_comment").children("#review_comment_review_text").val());
        var comment_review = $(this).parent("#new_comment_review").children("#comment_review_comment_text").val().trim();

        if(comment_review){
             $(this).hide();
             $($(this).parent("#new_comment_review").children(".img_loader_comment_review")).show();
             $($(this).parent("#new_comment_review").children(".image_preview_comment_review").children(".cancel_image_comment_review")).hide();
             $(this).parent("#new_comment_review").submit();
        }else{
            //$($(this).parent("#new_comment_review").children(".img_loader_comment_review")).hide("");
            //$(this).show();
            alert("Your comment is empty.");
        }
    });
    //End

    $('[id=post_article_comment]').live("click", function() {
        var article_comment = $(this).parent("#new_article_comment").children("#article_comment_comment_text").val().trim();

        if(article_comment){
            $(this).hide();
            $($(this).parent("#new_article_comment").children(".img_loader_article_comment")).show();
            $($(this).parent("#new_article_comment").children(".image_preview_article_comment").children(".cancel_image_article_comment")).hide();
            $(this).parent("#new_article_comment").submit();
        }else{
            //$($(this).parent("#new_comment_review").children(".img_loader_comment_review")).hide("");
            //$(this).show();
            alert("Your comment is empty.");
        }
    });

    //Review submit
    $('#post_review').live("click", function() {
        $(".img_loader_review").show();
        $('#post_review, .cancel_image_review').hide();
        setTimeout(function () {
            $("#new_review").submit();
        }, 2000);
    });

    $('#new_review').ajaxForm();
    //End

    //Update Review
    $('[id=post_update_review]').live("click", function(e) {
        //alert($(this).parent("#update_review").html());
        var review = $(this).parent().children("#update_review_review_text").val().trim();

        if(review){
            $(this).hide();
            $($(this).parent().children(".cancel_edit_review")).hide();
            $(this).parent().children(".img_loader_comment_review").show();
            $(this).parent("#update_review_form").submit();
        }else{
            alert("Your review is empty.");
        }
    });
    //End

    //Update Comment
    $('[id=post_update_comment],[id=post_update_article_comment]').live("click", function(e) {
        //alert($(this).parent().children("#update_comment_comment_text").val());
        var comment = $(this).parent().children("#update_comment_comment_text").val().trim();

        if(comment){
            $(this).hide();
            $($(this).parent().children(".cancel_edit_comment")).hide();
            $(this).parent().children(".img_loader").show();
            $(this).parent("#update_comment_form").submit();
        }else{
            alert("Your comment is empty.");
        }
    });
    //End

    $(".edit_comment, .edit_review, .follow, .cancel_edit_review, .cancel_edit_comment, .helpful_link, .rate-article, .rate_article").live("click",function(e){
        $.getScript(this.href);
        e.preventDefault();
        return false;
    });

    $(".report_review, .report_review_f").live("click",function(e){
        if(confirm("Report this review?")){
            $.getScript(this.href);
        }
        e.preventDefault();
        return false;
    });

    $(".report_comment").live("click",function(e){
        if(confirm("Report this comment?")){
            $.getScript(this.href);
        }
        e.preventDefault();
        return false;
    });

    $(".report_photo").live("click",function(e){
        if(confirm("Report this photo?")){
            $.getScript(this.href);
        }
        e.preventDefault();
        return false;
    });

    $(".report_video").live("click",function(e){
        if(confirm("Report this video?")){
            $.getScript(this.href);
        }
        e.preventDefault();
        return false;
    });

    $(".report_article").live("click",function(e){
        if(confirm("Report this article?")){
            $.getScript(this.href);
        }
        e.preventDefault();
        return false;
    });

    $(".delete_review, .delete_review_f").live("click",function(e){
        if(confirm("Are you sure you want to delete your review?")){
            $.fancybox.close();
            $.getScript(this.href);
        }
        e.preventDefault();
        return false;
    });

    $(".delete_comment").live("click",function(e){
        if(confirm("Are you sure you want to delete your comment?")){
            $.getScript(this.href);
        }
        e.preventDefault();
        return false;
    });

    $(".delete_photo").live("click",function(e){
        if(confirm("Are you sure you want to delete this photo?")){
            $.fancybox.close();
            $.getScript(this.href);
        }
        e.preventDefault();
        return false;
    });

    $(".delete_video").live("click",function(e){
        if(confirm("Are you sure you want to delete this video?")){
            $.fancybox.close();
            $.getScript(this.href);
        }
        e.preventDefault();
        return false;
    });

    $(".delete-article").live("click",function(e){
        if(confirm("Are you sure you want to delete this article?")){
            $.getScript(this.href);
        }
        e.preventDefault();
        return false;
    });

    $(".sort_link").live("click",function(e){
        $(".sort_link img").hide().attr('src', '#');
        $(".content_loader").show();
        $("#business_reviews").html("");
        $.getScript(this.href);
        e.preventDefault();
        return false;
    });

    $("#all-ratings").live("click",function(e){
        $('#review-default-sort-arrow').attr('src','/assets/arrow_up.png').css('display','inline');
    });

    //For Review image attachment
    $(".review-attach").live("click",function(){
        $('.review_uploaded_data').trigger('click');
    });

    $(".review_uploaded_data").live("click",function(){
        $(this).val("");
        $(".img_prev_review").attr('src', '#');
        $(".image_preview_review").hide();
    });

    $('.review_uploaded_data').live("change", function() {
        if (this.files && this.files[0]) {
            if(this.files[0].type.match('image.*')){
                if(this.files[0].size < 2097152){
                    $(".image_preview_review").show();
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        $(".img_prev_review").attr('src', e.target.result);
                    };
                    reader.readAsDataURL(this.files[0]);
                }else{
                    alert("Image Size is too big. Minimum size is 2MB.");
                    $(this).val("");
                }
            }else{
                alert("Not an image file.");
                $(this).val("");
            }
        }
    });

    $(".cancel_image_review").live("click",function(){
        $(".img_prev_review").attr("src", "#")
        $(".image_preview_review").hide();
        $(".review_uploaded_data").val("");
    });
    //end

    //For Article Comment image attachment
    $(".article-comment-attach").live("click",function(){
        $($(this).parent().children('.article_comment_uploaded_data')).trigger('click');
    });

    $(".article_comment_uploaded_data").live("click",function(){
        $(this).val("");
        $(this).parent().parent().children(".image_preview_article_comment").children(".img_prev_article_comment").attr('src', '#');
        $($(this).parent().parent().children(".image_preview_article_comment")).hide();
    });

    $('.article_comment_uploaded_data').live("change", function() {
        //alert($(this).parent().parent().children().html());
        if (this.files && this.files[0]) {
            if(this.files[0].type.match('image.*')){
                if(this.files[0].size < 2097152){
                    $($(this).parent().parent().children(".image_preview_article_comment")).show();
                    var img_tag = $(this).parent().parent().children(".image_preview_article_comment").children(".img_prev_article_comment");
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        $(img_tag).attr('src', e.target.result);
                    };
                    reader.readAsDataURL(this.files[0]);
                }else{
                    alert("Image Size is too big. Minimum size is 2MB.");
                    $(this).val("");
                }
            }else{
                alert("You can only upload image file.");
                $(this).val("");
            }
        }
    });

    $(".cancel_image_article_comment").live("click",function(){
        //alert($(this).parent().parent().children(".fileupload_comment_review").children(".comment_review_uploaded_data").val());
        $(this).parent(".image_preview_article_comment").children(".img_prev_article_comment").attr("src", "#")
        $(this).parent(".image_preview_article_comment").hide();
        $(this).parent().parent().children(".fileupload_article_comment").children(".article_comment_uploaded_data").val("");
    });
    //END

    //For Comment Review image attachment
    $(".comment-review-attach").live("click",function(){
        //alert($(this).parent().children('.comment_review_uploaded_data').html());
        $($(this).parent().children('.comment_review_uploaded_data')).trigger('click');
    });

    $(".comment_review_uploaded_data").live("click",function(){
        $(this).val("");
        $(this).parent().parent().children(".image_preview_comment_review").children(".img_prev_comment_review").attr('src', '#');
        $($(this).parent().parent().children(".image_preview_comment_review")).hide();
    });

    $('.comment_review_uploaded_data').live("change", function() {
        //alert($(this).parent().parent().children().html());
        if (this.files && this.files[0]) {
            if(this.files[0].type.match('image.*')){
                if(this.files[0].size < 2097152){
                    $($(this).parent().parent().children(".image_preview_comment_review")).show();
                    var img_tag = $(this).parent().parent().children(".image_preview_comment_review").children(".img_prev_comment_review");
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        $(img_tag).attr('src', e.target.result);
                    };
                    reader.readAsDataURL(this.files[0]);
                }else{
                    alert("Image Size is too big. Minimum size is 2MB.");
                    $(this).val("");
                }
            }else{
                alert("You can only upload image file.");
                $(this).val("");
            }
        }
    });

    $(".cancel_image_comment_review").live("click",function(){
        //alert($(this).parent().parent().children(".fileupload_comment_review").children(".comment_review_uploaded_data").val());
        $(this).parent(".image_preview_comment_review").children(".img_prev_comment_review").attr("src", "#")
        $(this).parent(".image_preview_comment_review").hide();
        $(this).parent().parent().children(".fileupload_comment_review").children(".comment_review_uploaded_data").val("");
    });
    //end

    //For BusinessPhoto image attachment
    $('#business_photo_uploaded_data').live("click", function() {
        $('#img_prev_photo').attr('src', '#');
        $('#image_preview_photo').hide();
        $(this).val("");
    });

    $('#business_photo_uploaded_data').live("change", function() {
        if (this.files && this.files[0]) {
            if(this.files[0].type.match('image.*')){
                if(this.files[0].size < 2097152){
                    $('#image_preview_photo').show();
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        $('#img_prev_photo').attr('src', e.target.result);
                    };
                    reader.readAsDataURL(this.files[0]);
                }else{
                    alert("Image Size is too big. Minimum size is 2MB.");
                    $(this).val("");
                }
            }else{
                alert("You can only upload image file.");
                $(this).val("");
            }
        }
    });

    $(".cancel_image_business_photo").live("click",function(){
        //alert($(this).parent().parent().children(".fileupload_comment_review").children(".comment_review_uploaded_data").val());
        $("#img_prev_photo").attr("src", "#")
        $("#image_preview_photo").hide();
        $("#business_photo_uploaded_data").val("");
        $("#association_photo_uploaded_data").val("");
    });
    //end

    //For BusinessArticle image attachment
    $('#article_photo_uploaded_data').live("click", function() {
        $('#img_prev_photo_article').attr('src', '');
        $('#image_preview_photo_article').hide();
        $(this).val("");
    });

    $('#article_photo_uploaded_data').live("change", function() {
        if (this.files && this.files[0]) {
            if(this.files[0].type.match('image.*')){
                if(this.files[0].size < 2097152){
                    $('#image_preview_photo_article').show();
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        $('#img_prev_photo_article').attr('src', e.target.result);
                    };
                    reader.readAsDataURL(this.files[0]);
                }else{
                    alert("Image Size is too big. Minimum size is 2MB.");
                    $(this).val("");
                }
            }else{
                alert("You can only upload image file.");
                $(this).val("");
            }
        }
    });

    $(".cancel_image_business_photo_article").live("click",function(){
        //alert($(this).parent().parent().children(".fileupload_comment_review").children(".comment_review_uploaded_data").val());
        $("#img_prev_photo_article").attr("src", "#")
        $("#image_preview_photo_article").hide();
        $("#business_article_uploaded_data").val("");
    });
    //end

    $(".business-article-clicked").live("click",function(){
        var article_id = $(this).attr("alt");

        $.ajax({
            type:"GET",
            url:"/article/clicked_article",
            data:{
                article:article_id,
                article_type:'business_article'
            }
        });
    });

    /*$("#t-rantsraves").live("click",function(e){
        $('.t-photos').removeClass('disableClick');
        $('.t-photos').attr('id','t-photos');
        e.preventDefault();
        return false;
    });*/

    //Business Page Tab Content Loader
    var biz_id = $('.ul-tabs').attr('alt');

    $("#t-rrok").live("click",function(e){
        //$(this).removeAttr('id');
        $("#business_reviews, .result-gallery-images, .result-gallery-videos, .tab-articles-content-1").html("");
        $(".content_loader").show();
        $.getScript('/business_review/business_reviews/'+biz_id);
        e.preventDefault();
        return false;
    });

    $("#t-photos").live("click",function(e){
        //$(this).removeAttr('id');
        $("#business_reviews, .result-gallery-images, .result-gallery-videos, .tab-articles-content-1").html("");
        $(".result-gallery-images").html("");
        $(".content_loader").show();
        $.getScript('/business_photo/business_photos/'+biz_id);
        e.preventDefault();
        return false;
    });

    $("#t-videos").live("click",function(e){
        //$(this).removeAttr('id');
        $("#business_reviews, .result-gallery-images, .result-gallery-videos, .tab-articles-content-1").html("");
        $(".result-gallery-videos").html("");
        $(".content_loader").show();
        $.getScript('/business_video/business_videos/'+biz_id);
        e.preventDefault();
        return false;
    });

    $("#t-articles").live("click",function(e){
        //$(this).removeAttr('id');
        $("#business_reviews, .result-gallery-images, .result-gallery-videos, .tab-articles-content-1").html("");
        $(".tab-articles-content-1").html("");
        $(".content_loader").show();
        $.getScript('/business_article/business_articles/'+biz_id);
        e.preventDefault();
        return false;
    });
    //END

     // shared review tab
     var shared_review_tab = $('#shared_review_tab').val();
     if (shared_review_tab > 0){
        $('html, body').animate({ scrollTop: $("#review-wrap-<%=params[:review_id]%>").offset().top }, 500);
     }
});